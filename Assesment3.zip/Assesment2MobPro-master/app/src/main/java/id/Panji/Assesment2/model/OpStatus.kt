package id.Panji.Assesment2.model

data class OpStatus(
    var status: String,
    var message: String?
)