package id.Panji.Assesment2.util

enum class SortingOrder {
    ASCENDING,
    DESCENDING
}