package id.Panji.Assesment2.model

data class Bukti(
    val id: String,
    val nominal: String,
    val kategori: String,
    val gambar: String,
    val auth: String,
    val mine: Int
)